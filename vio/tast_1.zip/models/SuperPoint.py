import torch
import numpy as np


class SuperPointNet(torch.nn.Module):
    """ Pytorch definition of SuperPoint Network. """

    def __init__(self):
        super(SuperPointNet, self).__init__()
        # TODO 添加SP的网络结构

    def forward(self, x):
        """ Forward pass that jointly computes unprocessed point and descriptor
    tensors.
    Input
      x: Image pytorch tensor shaped N x 1 x H x W.
    Output
      semi: Output point pytorch tensor shaped N x 65 x H/8 x W/8.
      desc: Output descriptor pytorch tensor shaped N x 256 x H/8 x W/8.
    """
        B, C, H, W = x.shape
        Hc = int(H / 8)
        Wc = int(W / 8)
        x = torch.sum(x, dim=1, keepdim=True) # 把输入的图像转换为灰度图
        # Shared Encoder.
        # TODO 添加SP的网络结构
        return heatmap, desc


class SuperPoint(object):
    def __init__(self, weights_path):
        self.net = SuperPointNet()
        self.net.load_state_dict(torch.load(weights_path, map_location='cpu'))
        self.net.eval()

    def __call__(self, img):
        """
        :param img: [B, 1, H, W] H, W % 64 == 0 in range [0,1].
        :return:  score map        [B, 1, H, W] in range [0,1].
                  local desc map 0 [B, 3, H, W]
                  local desc map 1 [B, 16, H/8, W/8] normalized
                  desc map         [B, 32, H/64, W/64]
        """
        B, C, H, W = img.shape
        assert H % 64 == 0 and W % 64 == 0
        if C == 3:
            img = torch.mean(img, dim=1, keepdim=True)
        with torch.no_grad():
            semi, desc = self.net(img)
        semi = semi.data.cpu().numpy().squeeze()
        dense = np.exp(semi) / (np.sum(np.exp(semi), axis=0) + 0.0001)
        nodust = dense[:-1, :, :].transpose(1, 2, 0)
        Hc = int(H / 8)
        Wc = int(W / 8)
        heatmap = np.reshape(nodust, [Hc, Wc, 8, 8])
        heatmap = np.transpose(heatmap, [0, 2, 1, 3])
        heatmap = np.reshape(heatmap, [Hc * 8, Wc * 8])
        desc_map_0 = torch.cat((img, torch.cat((img, img), dim=1)), dim=1)
        desc_map_0 = desc_map_0 / (torch.norm(desc_map_0, p=2, dim=1, keepdim=True) + 0.0001)
        desc_map_1 = desc[:, 0:4, :, :]
        desc_map_1 = desc_map_1 / (torch.norm(desc_map_1, p=2, dim=1, keepdim=True) + 0.0001)
        Hc = int(H / 64)
        Wc = int(W / 64)
        desc_map_2 = torch.zeros(1, 256, Hc, Wc)
        for i in range(Hc):
            for j in range(Wc):
                desc_map_2[:, :, i, j] = torch.mean(desc[:, :256, i * 8:(i + 1) * 8, j * 8:(j + 1) * 8], dim=(2, 3))
        desc_map_2 = desc_map_2 / (torch.norm(desc_map_2, p=2, dim=1, keepdim=True) + 0.0001)
        return torch.from_numpy(heatmap).unsqueeze(0).unsqueeze(0), desc_map_0, desc_map_1, desc_map_2


if __name__ == '__main__':
    from thop import profile
    import numpy as np
    net = SuperPointNet()
    net.load_state_dict(torch.load('../weights/superpoint_v1.pth', map_location='cpu'))
    net.eval()
    image = torch.tensor(np.random.random((1, 1, 512, 512)), dtype=torch.float32)
    flops, params = profile(net, inputs=(image,))
    print('{:<30}  {:<8} GFLops'.format('Computational complexity: ', flops / 1e9))
    print('{:<30}  {:<8} KB'.format('Number of parameters: ', params / 1e3))

