#include "extractor.h"

struct greaterThanPtr
{
    bool operator () (const float * a, const float * b) const
    // Ensure a fully deterministic result of the sort
    { return (*a > *b) || *a >= *b && (a > b); }
};

/**
 * @brief TODO 根据OpenCV的goodFeaturesToTrack函数实现角点检测
 * @param score_map
 * @param cell_size
 * @param kps
 * @return
 */
std::vector<cv::KeyPoint> nms(cv::InputArray score_map, int maxCorners,
                              double qualityLevel,double minDistance, cv::InputArray _mask)
{// 补全代码
}

cv::Mat bilinear_interpolation(int image_w, int image_h, const cv::Mat& desc_map,
                               const std::vector<cv::KeyPoint>& kps) {
    int w = desc_map.cols;
    int h = desc_map.rows;
    int c = desc_map.channels();
    cv::Mat desc((int)kps.size(), c, CV_32F);
    for (int i = 0; i < kps.size(); i++) {
        cv::KeyPoint kp = kps[i];
        float x = kp.pt.x / (float)image_w * (float)w;
        float y = kp.pt.y / (float)image_h * (float)h;
        int x0 = (int)x;
        int y0 = (int)y;
        int x1 = std::min(x0 + 1, w - 1);
        int y1 = std::min(y0 + 1, h - 1);
        float dx = x - (float)x0;
        float dy = y - (float)y0;
        for (int j = 0; j < c; j++) {
            float v00 = desc_map.at<float>(y0, x0 * c + j);
            float v01 = desc_map.at<float>(y1, x0 * c + j);
            float v10 = desc_map.at<float>(y0, x1 * c + j);
            float v11 = desc_map.at<float>(y1, x1 * c + j);
            desc.at<float>(i, j) = (1 - dx) * (1 - dy) * v00 + dx * (1 - dy) * v10 +
                                   (1 - dx) * dy * v01 + dx * dy * v11;
        }
    }

    return desc;
}
