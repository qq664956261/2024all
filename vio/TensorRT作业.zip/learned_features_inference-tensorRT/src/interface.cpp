#include "interface.h"
#include <cuda_runtime_api.h>
#include <utility>

class Logger : public nvinfer1::ILogger {
    void log(Severity severity, const char* msg) noexcept override {
        if (severity <= Severity::kWARNING)
            std::cout << msg << std::endl;
    }
} gLogger;

// TODO
Interface::Interface(std::string type, const std::string& modelPath, bool isGPU, cv::Size inputSize,
                     int _descriptor_width, int _descriptor_height, int _descriptor_dim, bool gray) {
    model_type = std::move(type);
    descriptor_width = _descriptor_width;
    descriptor_height = _descriptor_height;
    descriptor_dim = _descriptor_dim;

    // 1. 加载模型
    // 2. 预先分配CPU和GPU内存
    // 3. 推理前的初始化
}

Interface::~Interface() {
    int inputIndex = 0;
    int scoreOutputIndex = 1;
    int descriptorOutputIndex = 2;
    // 释放GPU内存
    cudaFree(buffers[inputIndex]);
    cudaFree(buffers[scoreOutputIndex]);
    cudaFree(buffers[descriptorOutputIndex]);

    delete engine;
    delete runtime;
    delete context;

    delete[] tmp_buffer;
}

/**
 * @brief TODO 运行推理
 * @param image
 */
void Interface::run(cv::Mat &image, cv::Mat& score_map_mat, cv::Mat& descriptor_map_mat) {
    // 1. 预处理
    // 2. 将输入拷贝到GPU
    // 3. 推理
    // 4. 将输出拷贝到CPU
    // 5. 后处理
}


/**
 * @brief Preprocess the image before feeding it to the network
 * @param image opencv image
 * @param blob
 * @param inputTensorShape
 */
void Interface::preprocessing(cv::Mat& image, float* &input) {
    cv::Mat resizedImage, floatImage;

    if (grayscale && image.channels() == 3) {
        // bgr -> gray
        cv::cvtColor(image, resizedImage, cv::COLOR_BGR2GRAY);
    } else if(!grayscale) {
        // bgr -> rgb
        cv::cvtColor(image, resizedImage, cv::COLOR_BGR2RGB);
    }

    // resize
    auto width = (int)(this->inputImageShape.width);
    auto height = (int)(this->inputImageShape.height);
    utils::letterbox(resizedImage, resizedImage, cv::Size(width, height),
                      cv::Scalar(114, 114, 114), false,
                      false, true, 32);
    // convert to float
    if (grayscale) {
        resizedImage.convertTo(floatImage, CV_32FC1, 1 / 255.0);
    } else {
        resizedImage.convertTo(floatImage, CV_32FC3, 1 / 255.0);
    }

    if (grayscale) {
        floatImage.copyTo(cv::Mat(floatImage.rows, floatImage.cols, CV_32FC1, input));
    } else {
        cv::Size floatImageSize{ floatImage.cols, floatImage.rows };
        // hwc -> chw
        std::vector<cv::Mat> chw(floatImage.channels());
        for (int i = 0; i < floatImage.channels(); ++i)
        {
            chw[i] = cv::Mat(floatImageSize, CV_32FC1, input + i * floatImageSize.width * floatImageSize.height);
        }
        cv::split(floatImage, chw);
    }
}

/**
 * @brief Postprocess the output of the network
 * @param request
 * @param score_map_mat
 * @param descriptor_map_mat
 */
void Interface::postprocessing(float* request, cv::Mat& desc_map) {
    const size_t height = desc_map.rows;
    const size_t width = desc_map.cols;
    const size_t num_channels = desc_map.channels();
    // chw -> hwc
    std::vector<cv::Mat> chw(num_channels);
    for (int i = 0; i < num_channels; ++i)
    {
        chw[i] = cv::Mat((int)height, (int)width, CV_32FC1, request + i * height * width);
    }
    cv::merge(chw, desc_map);
}





